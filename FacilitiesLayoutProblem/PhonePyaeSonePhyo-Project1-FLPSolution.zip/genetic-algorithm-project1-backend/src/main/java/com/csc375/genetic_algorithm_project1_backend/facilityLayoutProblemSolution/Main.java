package com.csc375.genetic_algorithm_project1_backend.facilityLayoutProblemSolution;

public class Main {
    static final int num_of_stations = 48;

    static final int num_of_threads = 64;
    static final int countOfGAOperations = 20000;


    public static void main(String[] args) {

//        Layout layout = new Layout(num_of_threads);
//        layout.evaluate(num_of_stations, countOfGAOperations);

    }
}