package com.csc375.genetic_algorithm_project1_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeneticAlgorithmProject1BackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
