import React, {useState} from 'react';
import {useStompClient, useSubscription} from "react-stomp-hooks";

const ChildComponent = () => {

    return (
        <h1></h1>
    );
};

export default ChildComponent;