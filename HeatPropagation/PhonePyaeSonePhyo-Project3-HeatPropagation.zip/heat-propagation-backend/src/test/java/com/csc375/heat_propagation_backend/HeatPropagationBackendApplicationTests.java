package com.csc375.heat_propagation_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HeatPropagationBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
