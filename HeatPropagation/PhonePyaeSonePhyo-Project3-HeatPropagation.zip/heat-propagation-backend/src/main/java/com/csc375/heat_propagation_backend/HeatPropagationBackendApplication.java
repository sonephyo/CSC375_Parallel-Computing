package com.csc375.heat_propagation_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HeatPropagationBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(HeatPropagationBackendApplication.class, args);
	}

}
