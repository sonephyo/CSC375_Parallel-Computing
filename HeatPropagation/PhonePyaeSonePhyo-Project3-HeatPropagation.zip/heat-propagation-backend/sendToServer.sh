#!/bin/bash

# Moving the updated folder to the server
scp -r ./out/** pphyo@gee.cs.oswego.edu:/home/pphyo/CSC375/HeatPropagation